__version__ = "1.0.2"
__author__ = "Paru Hang Rai"
__email__ = "paruhangrai.pri@gmail.com"

from .units_conv import res, cap, ind, volts, amps, freq, valufy 
__all__ = ['res', 'cap', 'ind', 'volts', 'amps', 'freq', 'valufy']